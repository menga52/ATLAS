from ATLAS.Models.Parameters import *

class HalfmoonParameters(Parameters):
	def __init__(self):
		self.init()
		
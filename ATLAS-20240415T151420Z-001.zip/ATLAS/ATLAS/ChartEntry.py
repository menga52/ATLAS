class ChartEntry:
  def __init__(self):
    self.LearningTime = None
    self.U = None
    self.V = None
    self.sigma = None
    self.sigma_fast = None
    self.Lambda = None
    self.b = None
    self.X_int = None
    self.WU = None
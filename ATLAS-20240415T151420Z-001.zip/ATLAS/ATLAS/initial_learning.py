from ATLAS.ATLAS.Learning_ini_chart import Learning_ini_chart

def initial_learning(model, verbose=False):
  if verbose:
    print("starting initial learning stage")
    Learning_ini_chart(model, verbose)
    